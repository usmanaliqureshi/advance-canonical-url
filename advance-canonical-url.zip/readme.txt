=== Advance Canonical URL ===
Contributors: usmanaliqureshi
Tags: canonical, url, canonical url, duplicate, duplicate content, content, avoid duplicate content, advance canonical url
Requires at least: 3.0
Tested up to: 4.8.1
Stable tag: 4.7.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A WordPress plugin to avoid duplicate content throughout the website with advance settings.

== Screenshots ==

1. Option for administrators to select canonical method.

2. Meta Box option for each post, page and custom post type.

== Changelog ==

= 1.0.0 =

* Initial Release
